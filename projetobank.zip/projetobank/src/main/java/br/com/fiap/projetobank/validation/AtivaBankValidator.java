package br.com.fiap.projetobank.validation;

import jakarta.validation.ConstraintValidator;
import jakarta.validation.ConstraintValidatorContext;

public class AtivaBankValidator implements ConstraintValidator<AtivaBank, String> {

    public boolean isValid(String value, ConstraintValidatorContext context) {
        return value.equals("ATIVA")|| value.equals("INATIVA");
    }
    
}
