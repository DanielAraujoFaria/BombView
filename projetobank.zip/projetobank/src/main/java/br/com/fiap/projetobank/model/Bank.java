package br.com.fiap.projetobank.model;

import java.math.BigDecimal;
import java.time.LocalDate;

import br.com.fiap.projetobank.validation.AtivaBank;
import br.com.fiap.projetobank.validation.TipoBank;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.PastOrPresent;
import jakarta.validation.constraints.Positive;
import jakarta.validation.constraints.Size;
import lombok.Data;

@Data
@Entity
public class Bank {
    

    @Id @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;

    @Column(unique = true)
    private Long numero;

    private String agencia;

    @NotBlank(message = "Nome não pode estar vazio")
    private String nome;

    @Size(min = 11, max = 11)
    private BigDecimal cpf;    

    @PastOrPresent(message = "Data não pode ser no futuro")
    private LocalDate data;
    
    @Positive(message = "Saldo inicial precisa ser positivo")
    private BigDecimal saldoini;
    
    @AtivaBank(message = "SIM ou NÃO")
    private boolean ativa;

    @TipoBank(message = "CORRENTE, POUPANÇA ou SALÁRIO")
    private String tipo;
}
