package br.com.fiap.projetobank.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import br.com.fiap.projetobank.model.Bank;

public interface BankRepository extends JpaRepository<Bank, Long>{
    
}
