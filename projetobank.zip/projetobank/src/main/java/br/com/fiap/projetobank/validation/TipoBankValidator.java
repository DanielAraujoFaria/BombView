package br.com.fiap.projetobank.validation;

import jakarta.validation.ConstraintValidator;
import jakarta.validation.ConstraintValidatorContext;

public class TipoBankValidator implements ConstraintValidator<TipoBank, String> {
    
    @Override
    public boolean isValid(String value, ConstraintValidatorContext context) {
        return value.equals("CORRENTE") || value.equals("POUPANCA") || value.equals("SALARIO");
    }
}
