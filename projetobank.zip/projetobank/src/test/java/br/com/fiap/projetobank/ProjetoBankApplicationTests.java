package br.com.fiap.projetobank;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProjetoBankApplicationTests {

	@Test
	void contextLoads() {
	}

}
